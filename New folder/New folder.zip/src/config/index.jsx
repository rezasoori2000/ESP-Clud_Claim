const address = {
  //apiUrl: "http://localhost:51804/api/",
  // apiUrl: "http://esp-claim-api:6598/api/",
  // apiUrl: "http://172.16.1.42/api/",
  apiUrl: "http://localhost:51804/api/",
};

export default address;
