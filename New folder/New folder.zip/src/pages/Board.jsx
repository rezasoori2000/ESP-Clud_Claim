import React from 'react';

const Board=()=>(
    <div>
        <h1>the Board page</h1>
    </div>
);

export default Board;
