import React from "react";

const Welcome = () => <div></div>;

export default Welcome;
