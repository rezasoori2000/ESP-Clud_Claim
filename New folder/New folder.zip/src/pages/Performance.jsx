import React from 'react';

const Performance=()=>(
    <div>
        <h1>the Performance page</h1>
    </div>
);

export default Performance;
