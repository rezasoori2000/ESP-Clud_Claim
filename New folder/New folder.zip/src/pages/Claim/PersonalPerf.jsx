import React from 'react';


const PersonalPerf=()=>(
    <div>
        <h1>the personal performance page</h1>
    </div>
);

export default PersonalPerf;