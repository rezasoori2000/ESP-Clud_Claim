import React from 'react';


const ClaimPartial=()=>(
    <div>
        <h1>the claim partial page</h1>
    </div>
);

export default ClaimPartial;